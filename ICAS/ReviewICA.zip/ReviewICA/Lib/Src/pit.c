//PIT Library
//Processor: MC9S12XDP512
//Crystal: 8 MHz
//by Bigoa Gach
//Oct. 03, 2022

#include "derivative.h"
#include "math.h"
#include "pit.h"

// ulBusRate      : bus frequency, in Hz
// ulInterval_us  : desired interval in us
// iDebugSegs     : option, debug info placed in segs (computed clocking values for PIT)
int PIT_Init0 (unsigned long ulBusRate, unsigned long ulInterval_us, int iDebugSegs) {

    unsigned long ulBusCycles = (ulInterval_us * pow(10, -6)) / (1 / ulBusRate);
    unsigned int iPotentialLarge = ulBusCycles;
    unsigned int iPotentialSmall = ulBusCycles / iPotentialLarge;
    unsigned int iSmall = 0;
    unsigned int iLarge = 0;
    
    //check for if the interval value is too large, 
    //default interval to max (256 * 65536 * 1/ulBusRate)
    //24Mhz -> max interval of 699[ms]
    //20Mhz -> max interval of 839[ms]
    //8Mhz  -> max interval of 2.10[s]
    if((ulBusCycles / 65535) > 255) {
        iSmall = 255;
        iLarge = 65535;
    }

    //check for if the interval value is smaller than the bus rate
    //default interval to double of the bus rate
    //24Mhz -> min interval of 83.3[ns]
    //20Mhz -> min interval of 100[ns]
    //8Mhz  -> min interval of 250[ns]
    if(ulInterval_us < (1 / ulBusRate)) {
        iSmall = 2;
        iLarge = 3;
    }

    while(iPotentialLarge > 65535 || iPotentialSmall < 2) {
        iLarge /= 2;
        iSmall = ulBusCycles / iLarge;
    }

    PITMTLD0 = iSmall - 1; 
    PITLD0 = iLarge - 1;
    // should yield ulInterval_us[us] interval (PITMTLD0 * PITLD0 * ulBusRate = ulInterval_us[us] per interrupt)
    // changing the two registers above determine the PIT interval
    // enable chan 0 (we will use channel 0 and channel 1 in this course)
    PITCE_PCE0 = 1; 
    // finally, enable periodic interrupt, normal in wait, PIT stalled in freeze
    // PIT still runs in wait mode (relevant next course)
    // PIT stalls when debugging so PIT events don’t pile up while stepping
    PITCFLMT = PITCFLMT_PITE_MASK | PITCFLMT_PITFRZ_MASK;

}
