//PWM Library
//Processor: MC9S12XDP512
//Crystal: 20 MHz
//by Bigoa Gach
//October 21st, 2022

//libraries
#include "derivative.h"
#include "pwmlib.h"

void PWM_8Bit_Init(unsigned long frequency, unsigned long clockSpeed, PWM_CH_BIT channel, BWM_Polarity poles, unsigned int period, unsigned int duty, BWM_ClockSelect clockX) {
    
    unsigned int clockVal;

    //set Clock A or B (8.3.2.4)
    PWMPRCLK &= clockX;

    //calculating what to divide the clock by
    clockVal = (int)(1.0 / (frequency * period * clockSpeed)) / 2;

    //set Clock SX to divide by 50 (8.3.2.10)
    if(clockX == ClockA)
        PWMSCLA = clockVal; //x2
    else if(clockX == ClockB)
        PWMSCLB = clockVal; //x2

    //select Clock SX for channel X (8.3.2.3)
    PWMCLK |= channel;

    //set polarity (8.3.2.2)
    if(poles)               //if StartLow
        PWMPOL &= ~channel; //set channel bit to 0
    else                    //if StartHigh
        PWMPOL |= channel;  //set channel bit to 1

    //program period (8.3.2.13)
    PWMPER2 = period;
    //program duty (8.3.2.14)
    PWMDTY2 = duty; // half period, so 50% duty

    //enable channel (8.3.2.1)
    PWME = channel;
}
